# from django.db import models
# from django.contrib.auth.models import AbstractUser

# class CustomUser(AbstractUser):
#     email = models.EmailField(unique=True)
#     full_name = models.CharField(max_length=100, blank=True)
#     phone_number = models.CharField(max_length=15, blank=True)
#     is_email_verified = models.BooleanField(default=False)
#     is_profile_completed = models.BooleanField(default=False)

#     USERNAME_FIELD = 'username'
#     REQUIRED_FIELDS = ['email']

#     def __str__(self):
#         return self.username


# class OTP(models.Model):
#     user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='otps')
#     code = models.CharField(max_length=6)
#     created_at = models.DateTimeField(auto_now_add=True)
#     is_used = models.BooleanField(default=False)

#     def __str__(self):
#         return f"OTP {self.code} for {self.user.username}"

#     class Meta:
#         ordering = ['-created_at']

from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    full_name = models.CharField(max_length=100, blank=True)
    phone_number = models.CharField(max_length=15, blank=True)
    is_email_verified = models.BooleanField(default=False)
    is_profile_completed = models.BooleanField(default=False)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    def __str__(self):
        return self.username

class OTP(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='otps')
    code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    def __str__(self):
        return f"OTP {self.code} for {self.user.username}"
    
    class Meta:
        ordering = ['-created_at']
