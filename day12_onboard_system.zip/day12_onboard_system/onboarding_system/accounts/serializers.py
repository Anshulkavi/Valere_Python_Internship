# from rest_framework import serializers
# from .models import CustomUser, OTP
# from .utils import generate_otp
# from django.contrib.auth import authenticate

# class RegisterSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = CustomUser
#         fields = ['username', 'password', 'email']
#         extra_kwargs = {
#             'password': {'write_only': True}
#         }
    
#     def create(self, validated_data):
#         user = CustomUser.objects.create_user(
#             username=validated_data['username'],
#             email=validated_data['email'],
#             password=validated_data['password']
#         )
#         return user


# class VerifyOTPSerializer(serializers.Serializer):
#     email = serializers.EmailField()
#     otp = serializers.CharField()

#     def validate(self, data):
#        if not data.get('email'):
#            raise serializers.ValidationError("Email is  required.")
#        return data
    

# class LoginSerializer(serializers.Serializer):
#     username = serializers.CharField()
#     password = serializers.CharField()

#     def validate(self, data):
#         username = data.get('username')
#         password = data.get('password')

#         if username and password:
#             user = authenticate(username=username, password=password)
#             if not user:
#                 raise serializers.ValidationError("Invalid credentials")
#             if not user.is_email_verified:
#                 raise serializers.ValidationError("Email is not verified")
#             data["user"] = user
#             return data
#         raise serializers.ValidationError("Must include username and password")
    

# class ProfileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = CustomUser
#         fields = [
#             'username',
#             'email',
#             'full_name',
#             'phone_number',
#             'is_email_verified',
#             'is_profile_completed',
#         ]

#     def get_full_name(self, obj):
#             return obj.full_name


#     def update(self, instance, validated_data):
#         instance.full_name = validated_data.get('full_name', instance.full_name)
#         instance.phone_number = validated_data.get('phone_number', instance.phone_number)
#         instance.is_profile_completed = True
#         instance.save()
#         return instance
    
# class CompleteProfileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = CustomUser
#         fields = ['full_name', 'phone_number']

from rest_framework import serializers
from .models import CustomUser, OTP
from django.contrib.auth import authenticate

class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['username', 'password', 'email']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        return CustomUser.objects.create_user(**validated_data)

class VerifyOTPSerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField()

    def validate(self, data):
        if not data.get('email'):
            raise serializers.ValidationError("Email is required.")
        return data

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        user = authenticate(username=data['username'], password=data['password'])
        if not user:
            raise serializers.ValidationError("Invalid credentials")
        if not user.is_email_verified:
            raise serializers.ValidationError("Email is not verified")
        data["user"] = user
        return data

class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [
            'username', 'email', 'full_name', 'phone_number',
            'is_email_verified', 'is_profile_completed'
        ]

    def update(self, instance, validated_data):
        instance.full_name = validated_data.get('full_name', instance.full_name)
        instance.phone_number = validated_data.get('phone_number', instance.phone_number)
        instance.is_profile_completed = True
        instance.save()
        return instance

class CompleteProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['full_name', 'phone_number']
