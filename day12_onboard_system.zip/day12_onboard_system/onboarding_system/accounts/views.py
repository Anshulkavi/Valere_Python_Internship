# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status,permissions
# from .models import CustomUser, OTP
# from .serializers import RegisterSerializer, VerifyOTPSerializer, LoginSerializer,ProfileSerializer,CompleteProfileSerializer
# from datetime import timedelta
# from django.utils import timezone
# from rest_framework_simplejwt.tokens import RefreshToken
# from rest_framework.permissions import IsAuthenticated
# from rest_framework.generics import RetrieveUpdateAPIView
# from .utils import send_otp_email,generate_otp,get_tokens_for_user
# from django.views.decorators.csrf import csrf_exempt
# from django.utils.decorators import method_decorator
# from django.views.decorators.csrf import csrf_exempt

# from django.shortcuts import render


# @method_decorator(csrf_exempt, name='dispatch')
# class RegisterView(APIView):
#     def post(self, request):
#         serializer = RegisterSerializer(data=request.data)
#         if serializer.is_valid():
#             user = serializer.save()

#             otp_code = generate_otp()
#             OTP.objects.create(user=user, code=otp_code, is_used=False)

#             # ✅ Fix: Get the user's email
#             request.session['email'] = user.email 

#             send_otp_email(user, otp_code)

#             return Response({'message': 'User registered, OTP sent'}, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# # @method_decorator(csrf_exempt, name='dispatch')
# # class VerifyOTPView(APIView):
# #     def post(self, request):
# #         serializer = VerifyOTPSerializer(data=request.data)
# #         if serializer.is_valid():
# #             email = serializer.validated_data.get('email')
# #             otp_input = serializer.validated_data['otp']

# #             try:
# #                 user = CustomUser.objects.get(email=email)
# #                 # ✅ Get the latest matching OTP that is unused
# #                 otp_obj = OTP.objects.filter(user=user, code=otp_input, is_used=False).latest('created_at')
# #             except (CustomUser.DoesNotExist, OTP.DoesNotExist):
# #                 return Response({"error": 'Invalid OTP or User'}, status=status.HTTP_400_BAD_REQUEST)
            
# #             # ✅ Check OTP expiration (5 mins)
# #             if timezone.now() - otp_obj.created_at > timedelta(minutes=5):
# #                 return Response({"error": "OTP expired"}, status=status.HTTP_400_BAD_REQUEST)
            
# #             # ✅ Mark OTP used and user verified
# #             otp_obj.is_used = True
# #             otp_obj.save()
# #             user.is_email_verified = True
# #             user.save()

# #             return Response({"message": 'OTP verified successfully'}, status=status.HTTP_200_OK)

# #         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# from django.contrib.auth import login

# @method_decorator(csrf_exempt, name='dispatch')
# class VerifyOTPView(APIView):
#     def post(self, request):
#         serializer = VerifyOTPSerializer(data=request.data)
#         if serializer.is_valid():
#             email = serializer.validated_data.get('email')
#             otp_input = serializer.validated_data['otp']

#             try:
#                 user = CustomUser.objects.get(email=email)
#                 otp_obj = OTP.objects.filter(user=user, code=otp_input, is_used=False).latest('created_at')
#             except (CustomUser.DoesNotExist, OTP.DoesNotExist):
#                 return Response({"error": 'Invalid OTP or User'}, status=status.HTTP_400_BAD_REQUEST)
            
#             if timezone.now() - otp_obj.created_at > timedelta(minutes=5):
#                 return Response({"error": "OTP expired"}, status=status.HTTP_400_BAD_REQUEST)
            
#             otp_obj.is_used = True
#             otp_obj.save()
#             user.is_email_verified = True
#             user.save()

#             # ✅ Issue JWT tokens after verification
#             tokens = get_tokens_for_user(user)

#             return Response({
#                 "message": "OTP verified and user logged in",
#                 "access": tokens["access"],
#                 "refresh": tokens["refresh"]
#             }, status=status.HTTP_200_OK)

#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @method_decorator(csrf_exempt, name='dispatch')

# class LoginView(APIView):
#     def post(self,request):
#         serializer = LoginSerializer(data=request.data)
#         if serializer.is_valid():
#             user = serializer.validated_data["user"]
#             refresh = RefreshToken.for_user(user)
#             return Response({
#                 "refresh": str(refresh),
#                 "access": str(refresh.access_token),
#                 "message": "Login successful"
#             })
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
# @method_decorator(csrf_exempt, name='dispatch')
# class ProfileView(RetrieveUpdateAPIView):
#     serializer_class = ProfileSerializer
#     permission_classes = [IsAuthenticated]

#     def get_object(self):
#         return self.request.user
    
# @method_decorator(csrf_exempt, name='dispatch')
# class LogoutView(APIView):
#     permission_classes = [permissions.IsAuthenticated]

#     def post(self, request):
#         print("Logout request data:", request.data)  # 👈 DEBUG line
#         try:
#             refresh_token = request.data['refresh']
#             token = RefreshToken(refresh_token)
#             token.blacklist()
#             return Response({"message": "Logout successful"}, status=status.HTTP_205_RESET_CONTENT)
#         except Exception as e:
#             print("Logout error:", str(e))  # 👈 DEBUG line
#             return Response({"error": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST)

# def onboarding_page(request):
#     return render(request, "accounts/onboarding.html")

# @method_decorator(csrf_exempt, name='dispatch')
# class CompleteProfileView(APIView):
#     permission_classes = [IsAuthenticated]

#     def post(self, request):
#         serializer = CompleteProfileSerializer(instance=request.user, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             request.user.is_profile_completed = True
#             request.user.save()
#             return Response({"detail": "Profile completed successfully."}, status=status.HTTP_200_OK)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .models import CustomUser, OTP
from .serializers import (
    RegisterSerializer, VerifyOTPSerializer, LoginSerializer,
    ProfileSerializer, CompleteProfileSerializer
)
from datetime import timedelta
from django.utils import timezone
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from rest_framework.generics import RetrieveUpdateAPIView
from .utils import send_otp_email, generate_otp, get_tokens_for_user
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required


@method_decorator(csrf_exempt, name='dispatch')
class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            otp_code = generate_otp()
            OTP.objects.create(user=user, code=otp_code)
            send_otp_email(user, otp_code)
            return Response({'message': 'User registered, OTP sent'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@method_decorator(csrf_exempt, name='dispatch')
class VerifyOTPView(APIView):
    def post(self, request):
        email = request.session.get('email') or request.data.get('email')
        otp = request.data.get('otp')

        if not email or not otp:
            return Response({'detail': 'Email and OTP required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = CustomUser.objects.get(email=email)
        except CustomUser.DoesNotExist:
            return Response({'detail': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        try:
            otp_obj = OTP.objects.get(user=user, code=otp)
        except OTP.DoesNotExist:
            return Response({'detail': 'Invalid OTP'}, status=status.HTTP_400_BAD_REQUEST)

        user.profile.is_email_verified = True
        user.profile.save()
        otp_obj.delete()

        tokens = get_tokens_for_user(user)

        return Response({
            'detail': 'Email verified successfully',
            'access': str(tokens['access']),
            'refresh': str(tokens['refresh']),
        }, status=status.HTTP_200_OK)


class ResendOTPView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user

        if user.is_email_verified:
            return Response({"detail": "Email is already verified."}, status=status.HTTP_400_BAD_REQUEST)

        otp = generate_otp()
        # Save OTP to model or cache (depending on your implementation)
        OTP.objects.update_or_create(user=user, defaults={"otp": otp})
        send_otp_email(user, otp)

        return Response({"detail": "A new OTP has been sent to your email."}, status=status.HTTP_200_OK)

@method_decorator(csrf_exempt, name='dispatch')
class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data["user"]
            refresh = RefreshToken.for_user(user)
            return Response({
                "refresh": str(refresh),
                "access": str(refresh.access_token),
                "message": "Login successful"
            })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@method_decorator(csrf_exempt, name='dispatch')
class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data['refresh']
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({"message": "Logout successful"}, status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response({"error": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST)

@method_decorator(csrf_exempt, name='dispatch')
class ProfileView(RetrieveUpdateAPIView):
    serializer_class = ProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

@method_decorator(csrf_exempt, name='dispatch')
class CompleteProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = CompleteProfileSerializer(instance=request.user, data=request.data)
        if serializer.is_valid():
            serializer.save()
            request.user.is_profile_completed = True
            request.user.save()
            return Response({"detail": "Profile completed successfully."}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def onboarding_page(request):
    return render(request, "accounts/onboarding.html")

@login_required
def trigger_verify_view(request):
    user = request.user
    otp_code = generate_otp()
    OTP.objects.update_or_create(user=user, defaults={"code": otp_code})
    send_otp_email(user, otp_code)
    request.session['email'] = user.email  # so verify view can pre-fill
    return redirect('/verify_otp/')  # Use path, not name, if not reversing