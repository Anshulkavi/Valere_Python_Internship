from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, OTP
# Register your models here.

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('username', 'email', 'is_email_verified', 'is_profile_completed', 'is_staff')
    list_filter = ('is_email_verified', 'is_profile_completed','is_staff', 'is_superuser')
    search_fields = ('username', 'email', 'phone_number')
    ordering = ('-date_joined',)

    fieldsets = UserAdmin.fieldsets + (
        ('Verification Info', {
            'fields': ('is_email_verified', 'is_profile_completed', 'phone_number'),
        }),
    )

    add_fieldsets = UserAdmin.add_fieldsets + (
    ('Additional Info', {
        'fields': ('phone_number',),
    }),
)



@admin.register(OTP)
class OTPAdmin(admin.ModelAdmin):
    list_display = ('user', 'code', 'created_at', 'is_used')
    list_filter = ('is_used', 'created_at')
    search_fields = ('user__username', 'user__email', 'code')
    ordering = ('-created_at',)